package com.example.gobang

class ViewModel {
    companion object{


    }
}